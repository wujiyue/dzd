该文件夹存放一些demo
demo1:js实现飘窗广告
