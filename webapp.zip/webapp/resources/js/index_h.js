

$(function(){

})
//加载用户菜单
function loadUserMenu()
{

}